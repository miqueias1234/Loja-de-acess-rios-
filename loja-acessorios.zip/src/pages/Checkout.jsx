import React, { useState } from "react";

export default function Checkout({ cart }) {
  const [submitted, setSubmitted] = useState(false);
  function handleSubmit(e) {
    e.preventDefault();
    setSubmitted(true);
  }

  if (submitted) return <div className="p-4">🎉 Pedido confirmado! Obrigado por comprar com a gente.</div>;

  return (
    <form onSubmit={handleSubmit} className="p-4 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Finalizar Compra</h2>
      <input required placeholder="Nome completo" className="block w-full mb-2 p-2 border rounded" />
      <input required type="email" placeholder="Email" className="block w-full mb-2 p-2 border rounded" />
      <textarea required placeholder="Endereço" className="block w-full mb-4 p-2 border rounded" />
      <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">Confirmar Pedido</button>
    </form>
  );
}