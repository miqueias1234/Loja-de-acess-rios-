import React from "react";
import { Link } from "react-router-dom";

export default function HomePage({ products, addToCart }) {
  return (
    <div className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
      {products.map((p) => (
        <div key={p.id} className="border rounded-xl shadow p-4">
          <img src={p.image} alt={p.name} className="w-full mb-2" />
          <h2 className="text-lg font-semibold">{p.name}</h2>
          <p className="text-green-600 font-bold">R$ {p.price.toFixed(2)}</p>
          <Link to={`/product/${p.id}`} className="text-blue-600 underline block my-2">Ver detalhes</Link>
          <button onClick={() => addToCart(p)} className="bg-blue-600 text-white px-4 py-1 rounded">Adicionar ao carrinho</button>
        </div>
      ))}
    </div>
  );
}