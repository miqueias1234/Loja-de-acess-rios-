import React, { useState } from "react";

export default function Admin({ products, setProducts }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");

  function addProduct(e) {
    e.preventDefault();
    const newProduct = {
      id: Date.now(),
      name,
      price: parseFloat(price),
      image,
    };
    setProducts([...products, newProduct]);
    setName(""); setPrice(""); setImage("");
  }

  function removeProduct(id) {
    setProducts(products.filter(p => p.id !== id));
  }

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Admin - Gerenciar Produtos</h2>
      <form onSubmit={addProduct} className="mb-6">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome" required className="block w-full mb-2 p-2 border rounded" />
        <input value={price} onChange={(e) => setPrice(e.target.value)} type="number" placeholder="Preço" required className="block w-full mb-2 p-2 border rounded" />
        <input value={image} onChange={(e) => setImage(e.target.value)} placeholder="URL da Imagem" required className="block w-full mb-2 p-2 border rounded" />
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded w-full">Adicionar Produto</button>
      </form>
      <ul>
        {products.map(p => (
          <li key={p.id} className="flex justify-between border-b py-2">
            <span>{p.name}</span>
            <button onClick={() => removeProduct(p.id)} className="text-red-500">Remover</button>
          </li>
        ))}
      </ul>
    </div>
  );
}