import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import HomePage from "./pages/HomePage";
import ProductPage from "./pages/ProductPage";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import Login from "./pages/Login";
import Admin from "./pages/Admin";
import { getUserFromStorage } from "./utils/auth";

export default function App() {
  const [cart, setCart] = useState([]);
  const [user, setUser] = useState(getUserFromStorage());
  const [products, setProducts] = useState(() => {
    return JSON.parse(localStorage.getItem("products")) || [
      { id: 1, name: "Pulseira de Prata", price: 79.9, image: "https://via.placeholder.com/150" },
      { id: 2, name: "Relógio Vintage", price: 149.9, image: "https://via.placeholder.com/150" },
      { id: 3, name: "Colar Minimalista", price: 59.9, image: "https://via.placeholder.com/150" },
    ];
  });

  useEffect(() => {
    localStorage.setItem("products", JSON.stringify(products));
  }, [products]);

  function addToCart(product) {
    setCart([...cart, product]);
  }

  function removeFromCart(index) {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  }

  return (
    <Router>
      <Navbar cart={cart} user={user} setUser={setUser} />
      <Routes>
        <Route path="/" element={<HomePage products={products} addToCart={addToCart} />} />
        <Route path="/product/:id" element={<ProductPage products={products} addToCart={addToCart} />} />
        <Route path="/cart" element={<Cart cart={cart} removeFromCart={removeFromCart} />} />
        <Route path="/checkout" element={<Checkout cart={cart} />} />
        <Route path="/login" element={<Login setUser={setUser} />} />
        <Route path="/admin" element={user?.isAdmin ? <Admin products={products} setProducts={setProducts} /> : <Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}