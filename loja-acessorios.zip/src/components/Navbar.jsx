import React from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Navbar({ cart, user, setUser }) {
  const navigate = useNavigate();

  function logout() {
    localStorage.removeItem("user");
    setUser(null);
    navigate("/");
  }

  return (
    <nav className="p-4 bg-black text-white flex justify-between items-center">
      <Link to="/" className="text-xl font-bold">Loja de Acessórios</Link>
      <div className="flex gap-4 items-center">
        <Link to="/cart">🛒 ({cart.length})</Link>
        {user ? (
          <>
            {user.isAdmin && <Link to="/admin">Admin</Link>}
            <button onClick={logout}>Sair</button>
          </>
        ) : (
          <Link to="/login">Entrar</Link>
        )}
      </div>
    </nav>
  );
}