import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginUser } from "../utils/auth";

export default function Login({ setUser }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  function handleLogin(e) {
    e.preventDefault();
    const user = loginUser(username, password);
    if (user) {
      setUser(user);
      navigate("/admin");
    } else {
      setError("Usuário ou senha inválidos");
    }
  }

  return (
    <form onSubmit={handleLogin} className="p-4 max-w-sm mx-auto">
      <h2 className="text-xl font-bold mb-4">Login do Admin</h2>
      <input value={username} onChange={(e) => setUsername(e.target.value)} required placeholder="Usuário" className="block w-full mb-2 p-2 border rounded" />
      <input value={password} onChange={(e) => setPassword(e.target.value)} required type="password" placeholder="Senha" className="block w-full mb-2 p-2 border rounded" />
      <button type="submit" className="bg-black text-white px-4 py-2 rounded w-full">Entrar</button>
      {error && <p className="text-red-600 mt-2">{error}</p>}
    </form>
  );
}