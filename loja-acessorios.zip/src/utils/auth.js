export function getUserFromStorage() {
  return JSON.parse(localStorage.getItem("user")) || null;
}

export function loginUser(username, password) {
  if (username === "admin" && password === "1234") {
    const user = { username, isAdmin: true };
    localStorage.setItem("user", JSON.stringify(user));
    return user;
  }
  return null;
}

export function logoutUser() {
  localStorage.removeItem("user");
}