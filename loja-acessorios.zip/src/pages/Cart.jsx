import React from "react";
import { Link } from "react-router-dom";

export default function Cart({ cart, removeFromCart }) {
  const total = cart.reduce((acc, item) => acc + item.price, 0);
  return (
    <div className="p-4 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Carrinho</h2>
      {cart.length === 0 ? (
        <p>O carrinho está vazio.</p>
      ) : (
        <>
          {cart.map((item, i) => (
            <div key={i} className="flex justify-between py-2 border-b">
              <span>{item.name}</span>
              <span>R$ {item.price.toFixed(2)}</span>
              <button onClick={() => removeFromCart(i)} className="text-red-500 ml-2">Remover</button>
            </div>
          ))}
          <p className="mt-4 text-xl font-bold">Total: R$ {total.toFixed(2)}</p>
          <Link to="/checkout" className="block mt-4 bg-blue-600 text-white text-center py-2 rounded">Finalizar Compra</Link>
        </>
      )}
    </div>
  );
}